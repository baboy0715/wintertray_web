﻿=============================================================
WINTERTRAY v1.0.0 (Hordozhato Verzio / Portable Edition)
=============================================================

Koszontunk a WinterTray asztali alkalmazasban!
Ez az elozetes kiadas a weboldal letoltesi csomagjakent szolgal.

Inditas:
Kattints duplan a WinterTray.exe fajlra.

Kovetelmenyek:
- Windows 10 (1903+) vagy Windows 11 (64-bit)
- DirectX 11 kompatibilis videokartya

Keszito: baboy0715
GitHub: https://github.com/baboy0715/wintertray_web
